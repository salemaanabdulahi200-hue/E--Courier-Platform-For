class PaymentsService {
  // TODO: Implement API methods for payments (customer)
} 