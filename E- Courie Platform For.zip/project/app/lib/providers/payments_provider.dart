import 'package:flutter/material.dart';

class PaymentsProvider extends ChangeNotifier {
  // TODO: Implement payment state and methods for customer
}
